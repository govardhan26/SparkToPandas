SparkToPandas
--------------

-----
The SparkToPandas is a pyspark supporting package which has the syntax similar to pandas, not all operations in pyspark are supported by this package.

If anyone is intersted in developing the package further or collaboration, please reachout.

*For more info, mail me @ govardhan_selvaraj@yahoo.com*

If you find this repository useful, buy me a coffee... :)

https://www.buymeacoffee.com/govardhan26

-----------




