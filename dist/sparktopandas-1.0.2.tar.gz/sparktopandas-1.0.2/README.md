-------------
# SparkToPandas
--------------



The SparkToPandas is a plugin for pyspark module, which has the syntax similar to the pandas module.

To install the package:

`pip install SparkToPandas`


Visit the [docs](https://sparktopandas.readthedocs.io/en/latest/index.html) page, for the official documentation.

If you are interested in enhancing the module or collaboration, please reachout.

*For more info, mail me @ govardhan_selvaraj@yahoo.com*

If you find this repository useful, [buy me a coffee](https://www.buymeacoffee.com/govardhan26)... :)

-----------




